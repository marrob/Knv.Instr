﻿/////////////////////////////////////////////////////////////////////////////
// Name:        RsHmc804x_Simple_Example
//
// Purpose:     RsHmc804x sample program to demonstrate simple setting of Voltage, Current limit on two channels + measurement
//              using an R&S HMP804x/NGE10x power supplies by utilizing the R&S IVI.NET RsHmc804x driver in C#
//
// Author:      
// Created:     10-December-2017
// Modified by: Miloslav Macko, 1DC3
// Modified:    10-April-2018
// Copyright:   (c) Rohde & Schwarz, Munich
/////////////////////////////////////////////////////////////////////////////

using System;
using System.Threading;
using System.Collections.Generic;
using System.Text;
using Ivi.Driver;
using RohdeSchwarz.RsHmc804x; //If missing, add the reference from:
// 64-bit target application:
//"C:\Program Files\IVI Foundation\IVI\Microsoft.NET\Framework64\v4.0.30319\RohdeSchwarz.RsHmc804x <version>\RohdeSchwarz.RsHmc804x.Fx40.dll"
// 32-bit target application:
//"C:\Program Files (x86)\IVI Foundation\IVI\Microsoft.NET\Framework32\v4.0.30319\RohdeSchwarz.RsHmc804x <version>\RohdeSchwarz.RsHmc804x.Fx40.dll"

//--------------------------------------------------------------------------
// Prerequisites
//
//   This sample program needs IVI Shared Components and IVI.NET Shared Components being installed.
//   If not yet done, visit
//     http://www.ivifoundation.org/shared_components/Default.aspx
//
//   Download and install
//     - IVI Shared Components 2.6.0
//     - IVI.NET Shared Components 1.4.0
//     - Rohde & Schwarz RsHmc804x IVI.NET driver 1.5.1
//
//   32-bit: IviSharedComponents_2.6.0.exe
//           IviNetSharedComponents32_Fx20_1.4.0.exe
//           RsHmc804x-ivi.net-x86-1_5_1.msi
//
//   64-bit: IviSharedComponents64_2.4.2.exe
//           IviNetSharedComponents64_Fx20_1.4.0.exe
//           RsHmc804x-ivi.net-x64-1_5_1.msi
//
//--------------------------------------------------------------------------

namespace RsHmc804x_Simple_Example
{
    class Program
    {
        static void Main(string[] args)
        {
            //Before running, change the resource name to fit your device:
            //For LAN interface use TCPIP::<IP_Address>::INSTR e.g. TCPIP::10.64.1.36::INSTR
            //For GPIB interface use the GPIB::<Address>::INSTR e.g. GPIB::28::INSTR
            //For USB-TMC interface use the USB::0x0AAD::<PID>::<SERIAL_NUMBER>::INSTR e.g. USB::0x0AAD::0x0197::100433::INSTR
            RsHmc804x driver;
            Console.Out.Write("Driver session initializing ... ");
            try
            {
                driver = new RsHmc804x("TCPIP::10.64.0.139::INSTR", true, true, "Simulate=False");
                //driver = new RsHmc804x("USB::0x0AAD::0x0135::032259070::INSTR", true, true, "Simulate=False");
                Console.WriteLine("finished");
                Console.Write("Instrument ID: ");
                Console.WriteLine(driver.UtilityFunctions.IDNQueryResponse);
            }
            //in case of the initializing error the driver throws an Ivi.Driver.IOException
            catch (Ivi.Driver.IOException e)
            {
                Console.Out.WriteLine("\nERROR: Cannot initialize the driver session.\nDetails:");
                Console.Out.WriteLine(e.Message);
                Console.Out.Write("\n\nPress any key to finish ... ");
                Console.ReadKey();
                return;
            }

            try
            {
                // Master output OFF
                driver.Outputs.MasterEnabled = true;

                // Select the channel 1. All further channel-commands are adressed to this channel
                driver.Outputs.SelectedChannel = 1;
                Console.Write("Configuring Channel 1 ... ");
                driver.Outputs.VoltageLevel = 1.23;
                driver.Outputs.CurrentLimit = 0.123;
                driver.Outputs.Ovp.Limit = 6.0;
                driver.Outputs.Ovp.Enabled = true;
                driver.Outputs.ChannelOnlyEnabled = true;
                Console.WriteLine("finished");

                Console.Write("Reconfiguring Channel 1 with a combined method Configure() ... ");
                driver.Outputs.Configure(1, 5.567, 0.124);
                Console.WriteLine("finished");

                // Select the channel 2. All further channel-commands are adressed to this channel
                driver.Outputs.SelectedChannel = 2;
                Console.Write("Configuring Channel 2 ... ");
                driver.Outputs.VoltageLevel = 2.34;
                driver.Outputs.CurrentLimit = 0.234;
                driver.Outputs.Ovp.Limit = 4.5;
                driver.Outputs.Ovp.Enabled = false;
                driver.Outputs.ChannelOnlyEnabled = true;
                Console.WriteLine("finished");

                Console.Write("Reconfiguring Channel 2 with a combined method Configure() ... ");
                driver.Outputs.Configure(2, 2.35, 0.235);
                Console.WriteLine("finished");

                // Master output ON
                Console.Write("Master Output ON ... ");
                driver.Outputs.MasterEnabled = true;
                Console.WriteLine("finished");

                driver.Outputs.SelectedChannel = 1;
                var measVoltageCH1 = driver.Outputs.Measure(MeasurementType.Voltage);
                Console.WriteLine("Measured Voltage on Channel 1: {0:F3} V", measVoltageCH1);
                driver.Outputs.SelectedChannel = 2;
                var measVoltageCH2 = driver.Outputs.Measure(MeasurementType.Voltage);
                Console.WriteLine("Measured Voltage on Channel 2: {0:F3} V", measVoltageCH2);
            }
            //driver IO error
            catch (Ivi.Driver.IOException e)
            {
                Console.WriteLine("Driver error occured:");
                Console.WriteLine(e.Message);
            }

            //driver function is not supported by this sensor
            catch (Ivi.Driver.OperationNotSupportedException e)
            {
                Console.WriteLine("Instrument doesn't support the function:");
                Console.WriteLine(e.Message);
            }

            //when a task takes longer than the defined timeout
            catch (Ivi.Driver.MaxTimeExceededException e)
            {
                Console.WriteLine("Operation took longer than the maximum defined time:");
                Console.WriteLine(e.Message);
            }

            //if the instrument returns an error in the error queue
            catch (Ivi.Driver.InstrumentStatusException e)
            {
                Console.WriteLine("Instrument system error occured:");
                Console.WriteLine(e.Message);
            }

            //if the instrument returns an error in the error queue
            catch (Ivi.Driver.SelectorNameException e)
            {
                Console.WriteLine("Invalid selector name used:");
                Console.WriteLine(e.Message);
            }

            finally
            {
                Console.Out.Write("\n\nPress any key to finish ... ");
                Console.ReadKey();
            }

        }
    }
}
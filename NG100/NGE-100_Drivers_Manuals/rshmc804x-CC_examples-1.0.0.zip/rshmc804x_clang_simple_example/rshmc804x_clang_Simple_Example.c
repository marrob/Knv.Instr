//==============================================================================
//
// Title:      rshmc804x_clang_Simple_Example
// Purpose:    rshmc804x sample program to demonstrate simple setting of Voltage, Current limit on two channels + measurement
//             using an R&S HMP804x/NGE10x power supplies by utilizing the R&S VXIpnp rshmc804x driver in CVI or Visual Studio C++
// Notes:      To run the example you need to install rshmc804x VXI Plug&Play instrument driver version 1.5.1 or later.
//             Default locations of instrument driver files on 32bit Windows:
//             C:\Program Files (x86)\IVI Foundation\VISA\WinNT\rshmc804x\rshmc804x.fp
//             C:\Program Files (x86)\IVI Foundation\VISA\WinNT\include\rshmc804x.h
//             C:\Program Files (x86)\IVI Foundation\VISA\WinNT\lib\msc\rshmc804x.lib
//             Default locations of instrument driver files on 64bit Windows:
//             C:\Program Files\IVI Foundation\VISA\Win64\rshmc804x\rshmc804x.fp
//             C:\Program Files\IVI Foundation\VISA\Win64\include\rshmc804x.h
//             C:\Program Files\IVI Foundation\VISA\Win64\lib\msc\rshmc804x.lib
//
// Created on: 2018-04-23 by Miloslav Macko.
// Copyright:  Rohde & Schwarz GmbH & Co. KG. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <rshmc804x.h>

//==============================================================================
// Constants
#define STRING_LENGTH 512  

//==============================================================================
// Types

//==============================================================================
// Static global variables

//Before running, change the resource name to fit your device:
//For LAN interface use TCPIP::<IP_Address>::INSTR e.g. TCPIP::10.64.1.36::INSTR
//For GPIB interface use the GPIB::<Address>::INSTR e.g. GPIB::28::INSTR
//For USB-TMC interface use the USB::0x0AAD::<PID>::<SERIAL_NUMBER>::INSTR e.g. USB::0x0AAD::0x0197::100433::INSTR
static ViString  gs_sResourceName = "TCPIP::10.64.1.36::INSTR";
static ViBoolean gs_hIDQuery = VI_TRUE;
static ViBoolean gs_hResetDevice = VI_TRUE;

//==============================================================================
// Global variables
ViSession g_Session = 0;

//==============================================================================
// Global functions
/// HIFN Checks for instrument error
/// HIRET Error code
/// HIPAR status/Status code to be checked, returned from instrument driver function call
ViStatus checkError (ViStatus status)
{
    ViChar  error_message [STRING_LENGTH];
    ViChar  error_buffer  [STRING_LENGTH * 2];
    ViChar* p2buf;
    ViInt32 error;
    
    if (status < VI_SUCCESS)
    {
        rshmc804x_error_message (g_Session, status, error_message);
        p2buf = error_buffer + sprintf (error_buffer, "Primary Error: 0x%08X, %s\n", status, error_message);
        
        
        /* This function reads an error code and a message from the instrument's error queue */
        rshmc804x_error_query (g_Session, &error, error_message);
        
        if (error != 0)
        {
            sprintf (p2buf, "Secondary Error: Instrument is reporting the following error (SYST:ERR?): %d, %s\n", error, error_message);
        }
        
        rshmc804x_close (g_Session);
    printf ("\nERROR!\n\n");
    printf (error_buffer);
    printf ("\nPress ENTER to continue...");
    (void) getchar();
        
    }
    return status;
}

//==============================================================================
// Macros
#define CHECKERR(fCal) \
    if (status = checkError(fCal), status < VI_SUCCESS) \
        return status; else


/// HIFN  The main entry-point function.
/// HIRET Returns 0 if successful. Otherwise returns instrument driver error 
/// HIRET code
int main (void)
{
  ViStatus status = VI_SUCCESS;
  ViChar   serror_message [256] = "No Error";
  ViChar   id_response[1024];
  
  printf ("Initializing instrument '%s' ... ", gs_sResourceName);
  CHECKERR (rshmc804x_init (gs_sResourceName, gs_hIDQuery, gs_hResetDevice, &g_Session));
  printf ("success.\n\n");
  
  printf ("Reading instrument *IDN? string ... ");
  CHECKERR (rshmc804x_IDQueryResponse (g_Session, id_response));
  printf ("success.\n\n");
  printf ("Connected instrument: %s\n\n", id_response);

  
  printf ("Configuring Channel 1 ... ");
  CHECKERR (rshmc804x_ConfigureOutput(g_Session, 1, 1.23, 0.123));
  CHECKERR (rshmc804x_ConfigureChannelOnlyEnabled(g_Session,1,VI_TRUE));
  printf ("success.\n\n");
  
  printf ("Configuring Channel 2 ... ");
  CHECKERR (rshmc804x_ConfigureOutput(g_Session, 2, 2.34, 0.345));
  CHECKERR (rshmc804x_ConfigureChannelOnlyEnabled(g_Session,2, VI_TRUE));
  printf ("success.\n\n");
  
  printf ("Master Output ON ... ");
  CHECKERR (rshmc804x_ConfigureMasterOutputEnabled(g_Session,VI_TRUE));
  printf ("success.\n\n");
  
  
  printf ("Closing the session to instrument '%s' ... ", gs_sResourceName);
  CHECKERR (rshmc804x_close (g_Session));
  printf ("success.\n\n");
  
  rshmc804x_error_message (0, status, serror_message);

  printf ("Example finished with status code '%ld' and status message:\n'%s'.\n", status, serror_message);
  printf ("\nPress ENTER to continue ... ");
  (void) getchar();

  return status;
}

